function love.load()
  love.graphics.setLineStyle('rough')
  theCanvas = love.graphics.newCanvas(800,600)
end

function love.update(dt)
  if love.mouse.isDown(1) then
    local newX,newY = love.mouse.getPosition()
    love.graphics.setCanvas(theCanvas)
    love.graphics.line(lastX,lastY,newX,newY)
    love.graphics.setCanvas()
    lastX,lastY = newX,newY
  end
end

function love.draw()
  love.graphics.draw(theCanvas)
end

function love.mousepressed(x,y,button)
  if button == 1 then
    lastX,lastY = x,y
  end
end
